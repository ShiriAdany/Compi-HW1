#include "tokens.hpp"

int main()
{
	int token;
	while(token = yylex()) {
	// Your code here
	}
	return 0;
}